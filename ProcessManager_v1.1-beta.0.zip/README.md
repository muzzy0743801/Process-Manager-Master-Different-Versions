# Process-Manager
a simple windows .NET C# process manager/computer information gatherer


# v2.0.0 Coming Soon!
Be on the look out for Process-Manager v2.0.0. It should be coming in the next 2 months.
